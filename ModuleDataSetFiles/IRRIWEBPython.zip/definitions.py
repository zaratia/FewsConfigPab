################################################################
#definisco directory di lavoro
# TODO adattarla alla struttura Fews
# TODO renderla funzionale per ogni OS
################################################################
import utils as ut
prjroot = str(ut.get_project_root())+"\\"

mypath = prjroot + "IRRIWEB\\Utility\\path.xml"





