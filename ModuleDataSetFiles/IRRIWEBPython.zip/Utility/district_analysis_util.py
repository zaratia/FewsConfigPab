#external modules
from osgeo import gdal
from osgeo import ogr
import os
import numpy as np
import pandas as pd
import xarray as xr
#internal modules
import shapefile
import Utility.plot_util as put

#convert xarray in tiff file (multiband too)
def xarr_to_tiff(myds, mycrs,foutn):
    myds = myds.rio.set_spatial_dims('x', 'y')
    myds.rio.set_crs(mycrs)
    myds.rio.to_raster(foutn)

def boundingBoxToOffsets(bbox, geot):
    col1 = int((bbox[0] - geot[0]) / geot[1])
    col2 = int((bbox[1] - geot[0]) / geot[1]) + 1
    row1 = int((bbox[3] - geot[3]) / geot[5])
    row2 = int((bbox[2] - geot[3]) / geot[5]) + 1
    return [row1, row2, col1, col2]


def geotFromOffsets(row_offset, col_offset, geot):
    new_geot = [
        geot[0] + (col_offset * geot[1]),
        geot[1],
        0.0,
        geot[3] + (row_offset * geot[5]),
        0.0,
        geot[5]
    ]
    return new_geot


def setFeatureStats(fid, min, max, mean, median, sd, sum, count, names=["min", "max", "mean", "median", "sd", "sum", "count", "id"]):
    featstats = {
        names[0]: min,
        names[1]: max,
        names[2]: mean,
        names[3]: median,
        names[4]: sd,
        names[5]: sum,
        names[6]: count,
        names[7]: fid,
    }
    return featstats

def zonal_stat(f_raster, f_zones):

    #get ogr and gdal driver
    mem_driver = ogr.GetDriverByName('ESRI Shapefile')
    mem_driver_gdal = gdal.GetDriverByName("MEM")
    shp_name = "temp"

    #open raster tu analize and zones shape file. return datasets
    r_ds = gdal.Open(f_raster)
    driver = ogr.GetDriverByName('ESRI Shapefile')
    p_ds = driver.Open(f_zones)
    #p_ds = ogr.Open(f_zones)

    #get layer from shp, geotransform and non value from shape (-9999)
    lyr = p_ds.GetLayer()
    geot = r_ds.GetGeoTransform()
    nodata = r_ds.GetRasterBand(1).GetNoDataValue()

    #create empty list for statistics data
    zstats = []
    zstatsarr = []

    #generate iterator on feature (zones)
    p_feat = lyr.GetNextFeature()
    niter = 0

    while p_feat:
        if p_feat.GetGeometryRef() is not None:
            if os.path.exists(shp_name):
                mem_driver.DeleteDataSource(shp_name)
            tp_ds = mem_driver.CreateDataSource(shp_name)
            tp_lyr = tp_ds.CreateLayer('polygons', None, ogr.wkbPolygon)
            tp_lyr.CreateFeature(p_feat.Clone())
            offsets = boundingBoxToOffsets(p_feat.GetGeometryRef().GetEnvelope(),
                                           geot)
            #offsets = [100, 127, 44, 89]

            new_geot = geotFromOffsets(offsets[0], offsets[2], geot)

            tr_ds = mem_driver_gdal.Create(
                "",
                offsets[3] - offsets[2],
                offsets[1] - offsets[0],
                1,
                gdal.GDT_Byte)
            tr_ds.SetGeoTransform(new_geot)
            gdal.RasterizeLayer(tr_ds, [1], tp_lyr, burn_values=[1])
            tr_array = tr_ds.ReadAsArray()

            r_array = r_ds.GetRasterBand(1).ReadAsArray(
                offsets[2],
                offsets[0],
                offsets[3] - offsets[2],
                offsets[1] - offsets[0])

            id = p_feat.GetFID()

            if r_array is not None:
                maskarray = np.ma.MaskedArray(
                    r_array, mask=np.logical_or(r_array==nodata, np.logical_not(tr_array)))

                if maskarray is not None:
                    zstats.append(setFeatureStats(
                        id,
                        maskarray.min(),
                        maskarray.max(),
                        maskarray.mean(),
                        np.ma.median(maskarray),
                        maskarray.std(),
                        maskarray.sum(),
                        maskarray.count()))
                    zstatsarr.append(np.array([
                        id,
                        maskarray.min(),
                        maskarray.max(),
                        maskarray.mean(),
                        np.ma.median(maskarray),
                        maskarray.std(),
                        maskarray.sum(),
                        maskarray.count()
                    ]))
                else:
                    zstats.append(setFeatureStats(
                        id,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata))
                    zstatsarr.append(np.array([
                        id,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata,
                        nodata
                    ]))
            else:
                zstats.append(setFeatureStats(
                    id,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata))
                zstatsarr.append(np.array([
                    id,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata,
                    nodata
                ]))

            tp_ds = None
            tp_lyr = None
            tr_ds = None

            p_feat = lyr.GetNextFeature()
    return np.array(zstatsarr)


def create_distric_monthly_analysis(ncin, crsin, var, fn_raster, fn_zones):
    shape = shapefile.Reader(fn_zones)
    feature = shape.shapeRecords()[0]
    superficie = feature.record[6]

    ds = xr.open_dataset(ncin)
    dateslabel = put.dates_to_label_netcdf(ds['t'])[0]
    idmonth = put.dates_to_label_netcdf(ds['t'])[1]

    #loop on day
    list_stats = []
    for iday in range(0, ds[var].shape[0]):
        #extract variable from xarray
        VAR = ds[var][iday,:,:]

        #create auxiliary tiff
        xarr_to_tiff(VAR, crsin,fn_raster)
        #cal statistical analizer
        myarraystats = zonal_stat(fn_raster, fn_zones)
        list_stats.append(myarraystats)

    stats = np.array(list_stats)
    mycolumns = [ "id", "min", "max", "mean", "median", "sd", "sum", "count"]
    df = pd.DataFrame(stats[:,0,:])

    df.columns = mycolumns
    df['tot'] = df['mean'] * superficie
    df['month'] = dateslabel
    df['idmonth'] = idmonth
    return df


def create_distric_daily_analysis(ncin, crsin, var, fn_raster, fn_zones):
    shape = shapefile.Reader(fn_zones)
    feature = shape.shapeRecords()[0]
    superficie = feature.record[6]

    ds = xr.open_dataset(ncin)
    dateslabel = put.dates_to_label_netcdf(ds['time'])[0]
    idmonth = put.dates_to_label_netcdf(ds['time'])[1]


    #loop on day
    list_stats = []
    for iday in range(0, ds[var].shape[0]):
        #extract variable from xarray
        VAR = ds[var][iday,:,:]

        #create auxiliary tiff
        xarr_to_tiff(VAR, crsin,fn_raster)
        #cal statistical analizer
        myarraystats = zonal_stat(fn_raster, fn_zones)
        list_stats.append(myarraystats)

    stats = np.array(list_stats)
    mycolumns = [ "id", "min", "max", "mean", "median", "sd", "sum", "count"]
    df = pd.DataFrame(stats[:,0,:])

    df.columns = mycolumns
    df['tot'] = df['mean'] * superficie
    df['month'] = dateslabel
    df['idmonth'] = idmonth
    list_dates=[]
    for it in range(0, len (ds["time"])):
        list_dates.append(str(int(ds["time"][it].dt.year)) + "-" + str(int(ds["time"][it].dt.month)) +
                          "-" + str(int(ds["time"][it].dt.day)))

    df["dates"] = list_dates
    return df


def create_distric_analysis(iday, ncin, crsin, var, fn_raster, fn_zones):
    shape = shapefile.Reader(fn_zones)
    feature = shape.shapeRecords()[0]
    superficie = feature.record[6]

    ds = xr.open_dataset(ncin)
    dateslabel = put.dates_to_label_netcdf(ds['time'])[0]
    idmonth = put.dates_to_label_netcdf(ds['time'])[1]


    #loop on day
    list_stats = []
    #extract variable from xarray
    VAR = ds[var][iday,:,:]

    #create auxiliary tiff
    xarr_to_tiff(VAR, crsin,fn_raster)
    #cal statistical analizer
    myarraystats = zonal_stat(fn_raster, fn_zones)
    list_stats.append(myarraystats)

    stats = np.array(list_stats)
    mycolumns = [ "id", "min", "max", "mean", "median", "sd", "sum", "count"]
    df = pd.DataFrame(stats[:,0,:])

    df.columns = mycolumns
    df['tot'] = df['mean'] * superficie
    return df





