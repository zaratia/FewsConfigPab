import numpy as np
import pandas as pd
from xml.dom.minidom import parseString
from dicttoxml import dicttoxml
import xmltodict
import xml.etree.ElementTree as ET
import definitions as de
import json
import codecs
import netCDF4 as nc


####################################################################
#xml simple interface##############################################
####################################################################

def dict_to_xml(mydict: dict,fileout: str) -> None:
    xml = dicttoxml(mydict)
    dom = parseString(xml).toprettyxml()
    xmlfile = open(fileout, "w")
    xmlfile.write(dom)
    xmlfile.close()

def plane_xml_parser(fin):
    tree = ET.parse(fin)
    root = tree.getroot()
    mydict=dict()
    for child in root:
        if child.attrib["type"] == "float":
            mydict[child.tag] = float(child.text)
        elif child.attrib["type"] == "int":
            mydict[child.tag] = int(child.text)
        else:
            mydict[child.tag] = child.text
    return mydict

def nested_xml_parser(fin):
    tree = ET.parse(fin)
    root = tree.getroot()
    mydict =dict()
    for child in root:
        if child.attrib["type"] == "float":
            mydict[child.tag] = float(child.text)
        elif child.attrib["type"] == "int":
            mydict[child.tag] = int(child.text)
        elif child.attrib["type"] == "str":
            mydict[child.tag] = child.text
        elif child.attrib["type"] == "dict":
            mydict[child.tag] = dict()
            for child1 in root.findall("./" + child.tag):
                for myi in child1.iter():
                    print(myi.tag, myi.attrib)



    #print(mydict)






####################################################################
#json simple interface##############################################
####################################################################

def array_to_json (inarray, outfile):
    outlist = inarray.tolist()
    json.dump(outlist, codecs.open(outfile, 'w', encoding='utf-8'), separators=(',', ':'), sort_keys=True, indent=4)

def list_to_json (inlist, outfile):
    json.dump(inlist, codecs.open(outfile, 'w', encoding='utf-8'), separators=(',', ':'), sort_keys=True, indent=4)

def json_to_array(infile):
    obj_text = codecs.open(infile, 'r', encoding='utf-8').read()
    b_new = json.loads(obj_text)
    return np.array(b_new)

def dict_to_json(mydict, fileout):
    with open(fileout, 'w') as json_file:
        json.dump(mydict, json_file)

def json_to_dict(filein):
    with open(filein, 'r') as json_file:
        mydict = json.load(json_file)
        return mydict


#########################################################################
#netcdf simple interface
##########################################################################
def create_netcdf4_file(fileout: str, gridin: dict, tsunit: str, startdate: str):
    ds = nc.Dataset(fileout, mode = 'w', format='NETCDF4')
    t = ds.createDimension('time',None)
    y = ds.createDimension('y', gridin['nrows'])
    x = ds.createDimension('x', gridin['ncols'])
    ts = ds.createVariable('time', 'f4', ('time',))
    ys = ds.createVariable('y', 'f4', ('y',))
    xs = ds.createVariable('x', 'f4', ('x',))
    xs.standardname = 'projection_x_coordinate'
    xs.units = 'm'
    xs.longname = 'x coordinate according to EPSG:3003'
    ys.standardname = 'projection_y_coordinate'
    ys.units = 'm'
    ys.longname = 'y coordinate according to EPSG:3003'
    ts.long_name = 'time'
    ts.units = tsunit + ' since ' + startdate
    return ds, ts, xs, ys



def create_netcdf4_variables(ncfin, name: str, stname: str, units: str):
    varout = ncfin.createVariable(name, np.float32, ('time','y','x'))
    varout.standard_name = stname
    varout.units = units
    return varout

def assigne_netcdf4_spatial_axes(grid_dict):
    #creo le liste con le coordinate
    pos_listx = []
    pos_listy = []
    for i in range (0, grid_dict['ncols']):
        pos_listx.append(grid_dict['xllcorner'] + grid_dict['cellsize'] * i + grid_dict['cellsize']/2)
    for i in range (0, grid_dict['nrows']):
        pos_listy.append(grid_dict['yllcorner'] + (grid_dict['nrows']-1)* grid_dict['cellsize'] - grid_dict['cellsize'] * i
                         + grid_dict['cellsize']/2)
    #scrivo due array con x e y per netcdf
    xs = np.array(pos_listx)
    ys = np.array(pos_listy)
    return xs, ys

#############################################
#convert data from nc files
#############################################

def nc_to_date(index_nct, nct):
    date = nc.num2date(nct[index_nct], nct.units)
    d_t_1 = str(date)[:10]
    dti = pd.date_range(d_t_1, d_t_1, freq='1 D')
    df = pd.DataFrame(dti)
    df.columns = ['date_time']
    df['j']=df['date_time'].dt.dayofyear
    df['year'] = df['date_time'].dt.year
    df['month'] = df['date_time'].dt.month
    df['day'] = df['date_time'].dt.day
    year = str(df['year'][0])
    if len(str(df['month'][0]))==1:
        month = '0'+ str(df['month'][0])
    else:
        month = str(df['month'][0])
    if len(str(df['day'][0]))==1:
        day = '0'+ str(df['day'][0])
    else:
        day = str(df['day'][0])
    str_date = year+month+day
    return df.j[0], d_t_1, str_date, year, month, day