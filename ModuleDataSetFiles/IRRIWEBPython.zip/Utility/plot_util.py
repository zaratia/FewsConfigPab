import matplotlib.pyplot as plt

def int_to_month(mint):
    mlit = ''
    if mint == 1:
        mlit = 'Gen'
    elif mint == 2:
        mlit = 'Feb'
    elif mint == 3:
        mlit = 'Mar'
    elif mint == 4:
        mlit = 'Apr'
    elif mint == 5:
        mlit = 'Mag'
    elif mint == 6:
        mlit = 'Giu'
    elif mint == 7:
        mlit = 'Lug'
    elif mint == 8:
        mlit = 'Ago'
    elif mint == 9:
        mlit = 'Set'
    elif mint == 10:
        mlit = 'Ott'
    elif mint == 11:
        mlit = 'Nov'
    elif mint == 12:
        mlit = 'Dic'
    return mlit

def get_tlabel_formatted(x,tlfmt,month='All', step=1):
    myt = []
    for it in range(0, len(x)):
        if tlfmt == '%Y-%m-%d':

            y = str(int(x[it].dt.year))
            if len(str(int(x[it].dt.month))) ==1:
                m = '0' + str(int(x[it].dt.month))
            else:
                m  = str(int(x[it].dt.month))
            if len(str(int(x[it].dt.day))) ==1:
                d = '0' + str(int(x[it].dt.day))
            else:
                d  = str(int(x[it].dt.day))
            if (it%step):
                myt.append('')
            else:
                myt.append(y+'-' + m + '-' + d)

        elif tlfmt == '%m-%Y':
            y = str(int(x[it].dt.year))
            if len(str(int(x[it].dt.month))) ==1:
                m = '0' + str(int(x[it].dt.month))
            else:
                m  = str(int(x[it].dt.month))
            if (it%step):
                myt.append('')
            else:
                myt.append(m+'-' + y)

        elif tlfmt == '%strm-%Y':
            y = str(int(x[it].dt.year))
            m = int_to_month(int(x[it].dt.month))
            if m == month or month =='All':
                myt.append(m+'-' + y)
            else:
                myt.append('')

    return(myt)


def get_tlabel_formatted_timestamp(x,tlfmt,month='All', step=1):
    myt = []
    for it in range(0, len(x)):
        if tlfmt == '%Y-%m-%d':

            y = str(int(x[it].year))
            if len(str(int(x[it].month))) ==1:
                m = '0' + str(int(x[it].month))
            else:
                m  = str(int(x[it].month))
            if len(str(int(x[it].day))) ==1:
                d = '0' + str(int(x[it].day))
            else:
                d  = str(int(x[it].day))
            if (it%step):
                myt.append('')
            else:
                myt.append(y+'-' + m + '-' + d)

        elif tlfmt == '%m-%Y':
            y = str(int(x[it].year))
            if len(str(int(x[it].month))) ==1:
                m = '0' + str(int(x[it].month))
            else:
                m  = str(int(x[it].month))
            if (it%step):
                myt.append('')
            else:
                myt.append(m+'-' + y)

        elif tlfmt == '%strm-%Y':
            y = str(int(x[it].year))
            m = int_to_month(int(x[it].month))
            myt.append(m+'-' + y)

    return(myt)

def plot_H(x,xfmt, y,title='',xlabel='',ylabel='',mymonth='All'):
    fig = plt.figure(figsize=(10,8))
    fig.subplots_adjust(bottom=0.15)
    ax = fig.add_subplot(111)
    if xfmt=='ts':
        label = get_tlabel_formatted_timestamp(x, '%strm-%Y', month=mymonth)
    else:
        label = get_tlabel_formatted(x, '%strm-%Y', month=mymonth)
    ax.plot(label,y, 'bo-')
    if title !='':
        ax.set_title(title, fontsize=18)

    if xlabel!='':
        ax.set_xlabel(xlabel,
                      family='serif',
                      color='k',
                      weight='normal',
                      size = 18,
                      labelpad = 6)

    if ylabel !='':
        ax.set_ylabel(ylabel,
                      family='serif',
                      color='k',
                      weight='normal',
                      size = 18,
                      labelpad = 6)

    if mymonth != 'All':
        mytick = []
        for ilab in range(0, len(label)):
            if label[ilab][:3] == mymonth:
                mytick.append(label[ilab])

        ax.xaxis.set_ticks(mytick)
    else:
        ax.xaxis.set_ticks(label)
    plt.xticks(fontsize=14)
    plt.xticks(family='serif',
               color='k')
    plt.xticks(rotation = 45)

    plt.yticks(fontsize=14)
    plt.yticks(family='serif',
               color='k')

    plt.grid()
    plt.show()

def plot1 (x,y,simbol, color, xt,yt,xl,yl,title, series):
    fig = plt.figure(figsize=(11,9))
    ax = fig.add_subplot(111)
    ax.plot(x,y,color+simbol)

    legend = plt.legend([series], title = "Legenda")


    ax.set_ylabel("[mm day-1]",
                  family='serif',
                  color='k',
                  weight='normal',
                  size = 18,
                  labelpad = 6)
    if len(xt):
        ax.xaxis.set_ticks(xt)
    if len(yt):
        ax.yaxis.set_ticks(yt)

    plt.xticks(fontsize=13)
    plt.xticks(family='serif',
               color='k')
    plt.xticks(rotation = 45)

    plt.yticks(fontsize=13)
    plt.yticks(family='serif',
               color='k')

    plt.grid()
    plt.show()

def plot2_barline (x,y1, y2, xt,y1t,y2t, xl,yl, y2l,title,series):
    fig = plt.figure(figsize=(11,9))
    ax1 = fig.add_subplot(111)
    ax2 = ax1.twinx()
    ax1.plot(x,y1,'r-')
    ax1.set_ylim(min(y1)-2,max(y1)+max(y2))
    ax2.bar(x,y2)
    ax2.set_ylim(0,max(y1)+max(y2))
    ax2.invert_yaxis()


    #legend = plt.legend([series], title = "Legenda")


    ax1.set_ylabel("[mm day-1]",
                  family='serif',
                  color='r',
                  weight='normal',
                  size = 18,
                  labelpad = 6)

    ax2.set_ylabel("[mm day-1]",
                   family='serif',
                   color='b',
                   weight='normal',
                   size = 18,
                   labelpad = 6)


    if len(xt):
        ax1.xaxis.set_ticks(xt)
    if len(y1t):
        ax1.yaxis.set_ticks(y1t)
    if len(y2t):
        ax2.yaxis.set_ticks(y2t)

    plt.xticks(fontsize=13)
    plt.xticks(family='serif',
               color='k')
    plt.xticks(rotation = 45)

    plt.yticks(fontsize=13)
    plt.yticks(family='serif',
               color='k')



    plt.grid()
    plt.show()


def dates_to_label_netcdf(mydata):
    label = []
    idlabel = []
    for j in range(0,len(mydata)):
        label.append(int_to_month(int(mydata[j].dt.month)) + '-' + str(int(mydata[j].dt.year)))
        idlabel.append(int_to_month(int(mydata[j].dt.month)))

    return label, idlabel


def plot3 (x,y1,y2,y3, simbol, color, xt,yt,xl,yl,title, series):
    fig = plt.figure(figsize=(11,9))
    ax = fig.add_subplot(111)
    ax.plot(x,y1,color[0]+simbol[0])
    ax.plot(x,y2,color[1]+simbol[1])
    ax.plot(x,y3,color[2]+simbol[2])

    legend = plt.legend([series[0],series[1],series[2]], title = "Legenda")


    ax.set_ylabel("[mm day-1]",
                  family='serif',
                  color='k',
                  weight='normal',
                  size = 18,
                  labelpad = 6)
    if len(xt):
        ax.xaxis.set_ticks(xt)
    if len(yt):
        ax.yaxis.set_ticks(yt)

    plt.xticks(fontsize=13)
    plt.xticks(family='serif',
               color='k')
    plt.xticks(rotation = 45)

    plt.yticks(fontsize=13)
    plt.yticks(family='serif',
               color='k')

    plt.grid()
    plt.show()
