import os
import netCDF4 as nc
import pandas as pd
import numpy as np
import Utility.ioutil as iou
import definitions as de
MYPATH = iou.plane_xml_parser(de.mypath)

def get_VST0(startdate):
    inf = MYPATH["VST0"] + "*"
    outf = MYPATH["IN"]
    os.system("rm {}*".format(outf))
    os.system("cp {} {}".format(inf,outf))
    df = pd.DataFrame()
    df["DATE"]= [startdate]
    df.to_csv(outf + "VST_DATE.csv")

def get_vars(startdate,enddate):
    intp = MYPATH["IN_TP"] + "TP_" + startdate + "_" +enddate+".nc"
    outp = MYPATH["IN"] + "in_TP.nc"
    os.system("cp {} {}".format(intp,outp))
    intamax = MYPATH["IN_TAmax"] + "TAmax_" + startdate + "_" +enddate+".nc"
    outamax = MYPATH["IN"] + "in_TAmax.nc"
    os.system("cp {} {}".format(intamax,outamax))
    intamin = MYPATH["IN_TAmin"] + "TAmin_" + startdate + "_" +enddate+".nc"
    outamin = MYPATH["IN"] + "in_TAmin.nc"
    os.system("cp {} {}".format(intamin,outamin))


def import_vars_CNC_HGR(mypath, myname):
    TAmax_ds = nc.Dataset(mypath["TAmax"])
    TAmax_ts = TAmax_ds[myname["Time"]]
    TAmax = TAmax_ds[myname["Maximum_daily_temperature"]]

    TAmin_ds = nc.Dataset(mypath["TAmin"])
    TAmin_ts = TAmin_ds[myname["Time"]]
    TAmin = TAmin_ds[myname["Minimum_daily_temperature"]]

    TP_ds = nc.Dataset(mypath["TP"])
    TP_ts = TP_ds[myname["Time"]]
    TP = TP_ds[myname["Cumulative_daily_precipitation"]]

    return TAmax_ds, TAmin_ds, TP_ds, TAmax_ts, TAmin_ts, TP_ts, TAmax, TAmin, TP

def get_vsts_CNC_HGR(mypath):
    ANTRF1 = iou.json_to_array(mypath["ANTRF1"])
    ANTRF2 = iou.json_to_array(mypath["ANTRF2"])
    ANTRF3 = iou.json_to_array(mypath["ANTRF3"])
    ANTRF4 = iou.json_to_array(mypath["ANTRF4"])
    ANTRF5 = iou.json_to_array(mypath["ANTRF5"])

    SS = pd.read_csv(mypath["VST_SS"])["SS"][0]
    Gi =  pd.read_csv(mypath["VST_GW"])["GW"][0]
    Smaxi = pd.read_csv(mypath["VST_SM"])["SM"][0]
    Si = pd.read_csv(mypath["VST_ST"])["ST"][0]
    Wi = pd.read_csv(mypath["VST_W0"])["W0"][0]
    VSTS_DATE = pd.read_csv(mypath["VST_DATE"])["DATE"][0]
    return ANTRF1, ANTRF2, ANTRF3, ANTRF4, ANTRF5, SS, Gi, Smaxi, Si, Wi, VSTS_DATE

def write_result_ro(mypath, mysim, myname):
    gridin = iou.json_to_dict(mypath["GRID_DICT"])
    stda = mysim["START_DATE"]
    startdate = stda[:4] + "-" + stda[4:6]+ "-" + stda[6:]

    fout = mypath["out_RO"]
    RO_ds, RO_ts, RO_xs, RO_ys = iou.create_netcdf4_file(fout, gridin, "DAY", startdate)
    RO_xs[:], RO_ys[:] = iou.assigne_netcdf4_spatial_axes(gridin)
    RO = iou.create_netcdf4_variables(RO_ds,myname["Direct_runoff_name"],
                                      myname["Direct_runoff_longname"],
                                      myname["Direct_runoff_units"])

    fout = mypath["out_INF"]
    IN_ds, IN_ts, IN_xs, IN_ys = iou.create_netcdf4_file(fout, gridin, "DAY", startdate)
    IN_xs[:], IN_ys[:] = iou.assigne_netcdf4_spatial_axes(gridin)
    IN = iou.create_netcdf4_variables(IN_ds,myname["Infiltration_name"],
                                      myname["Infiltration_longname"],
                                      myname["Infiltration_units"])


    return RO_ds, RO_ts, RO_xs, RO_ys, RO, IN_ds, IN_ts, IN_xs, IN_ys, IN


def write_result_et(mypath, mysim, myname):
    gridin = iou.json_to_dict(mypath["GRID_DICT"])
    stda = mysim["START_DATE"]
    startdate = stda[:4] + "-" + stda[4:6]+ "-" + stda[6:]

    fout = mypath["out_E0"]
    EO_ds, EO_ts, EO_xs, EO_ys = iou.create_netcdf4_file(fout, gridin, "DAY", startdate)
    EO_xs[:], EO_ys[:] = iou.assigne_netcdf4_spatial_axes(gridin)
    EO = iou.create_netcdf4_variables(EO_ds,myname["Potential_evapotraspiration_name"],
                                      myname["Potential_evapotraspiration_longname"],
                                      myname["Potential_evapotraspiration_units"])

    fout = mypath["out_EC"]
    EC_ds, EC_ts, EC_xs, EC_ys = iou.create_netcdf4_file(fout, gridin, "DAY", startdate)
    EC_xs[:], EC_ys[:] = iou.assigne_netcdf4_spatial_axes(gridin)
    EC = iou.create_netcdf4_variables(EC_ds,myname["Evapotraspiration_name"],
                                      myname["Evapotraspiration_longname"],
                                      myname["Evapotraspiration_units"])



    return EO_ds, EO_ts, EO_xs, EO_ys, EO, EC_ds, EC_ts, EC_xs, EC_ys, EC


def get_ANTRF(myiday, iday, rf, list_antrf):
    if myiday == 0:
        ANTRF = np.sum(np.array(list_antrf[:])**2, axis=0)
    elif myiday == 1:
        ANTRF = np.sum(np.array(list_antrf[:len(list_antrf)-myiday])**2, axis=0) \
                + np.sum(rf[iday-myiday:iday,:,:]**2,axis=0)
    elif myiday == 2:
        ANTRF = np.sum(np.array(list_antrf[:len(list_antrf)-myiday])**2, axis=0) \
                + np.sum(rf[iday-myiday:iday,:,:]**2,axis=0)
    elif myiday == 3:
        ANTRF = np.sum(np.array(list_antrf[:len(list_antrf)-myiday])**2, axis=0) \
                + np.sum(rf[iday-myiday:iday,:,:]**2,axis=0)
    elif myiday == 4:
        ANTRF = np.sum(np.array(list_antrf[:len(list_antrf)-myiday])**2, axis=0) \
                + np.sum(rf[iday-myiday:iday,:,:]**2,axis=0)
    else:
        ANTRF = np.sum(rf[iday-5:iday,:,:]**2,axis=0)
    return ANTRF

def write_state(date_str, ss, gi,si,wi, mypath):
    df = pd.DataFrame()
    df["DATE"] = [date_str]
    df.to_csv(mypath["VST_DATE"])
    del(df)

    df = pd.DataFrame()
    df["SS"] = [ss]
    df.to_csv(mypath["VST_SS"])
    del(df)

    df = pd.DataFrame()
    df["GW"] = [gi]
    df.to_csv(mypath["VST_GW"])
    del(df)

    df = pd.DataFrame()
    df["SM"] = [ss-gi]
    df.to_csv(mypath["VST_SM"])
    del(df)

    df = pd.DataFrame()
    df["ST"] = [si]
    df.to_csv(mypath["VST_ST"])
    del(df)

    df = pd.DataFrame()
    df["W0"] = [wi]
    df.to_csv(mypath["VST_W0"])
    del(df)

def read_path():
    fpath = de.prjroot + "IRRIWEB\\utility\\path.xml"
    frelpath = de.prjroot + "IRRIWEB\\utility\\relpath.xml"
    fname = de.prjroot + "IRRIWEB\\utility\\name.xml"
    mypath = iou.plane_xml_parser(frelpath)
    for elem in mypath:
        mypath[elem] = de.prjroot + "IRRIWEB\\" + mypath[elem]
    iou.dict_to_xml(mypath, fpath)
    return fpath, fname


fpath, fname = read_path()

