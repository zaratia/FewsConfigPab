import numpy as np
import Utility.district_analysis_util as daut

def rf(inf_in, s_in, smin_in, kg,bg):
    s = float(s_in) + inf_in
    rf = np.round(1/kg*(s-smin_in)**bg,1)

    if rf> s - smin_in: rf = s-smin_in

    #scarico lo storage in falda
    s1 = s-rf
    return s1, rf

def et(s1, etc, smin_in, smax_in,bet):
    ket  = 1 - (1 -s1/smax_in)**bet
    et = ket*etc
    et [et> s1 - smin_in] =  s1 - smin_in
    return et

def gw(s1,rf, et1,g_in, w0, kb, eb, ss):
    s_f = s1-et1

    #ricarico la falda
    g = g_in + rf

    #calcolo il deflusso
    d = g -w0
    if d >= 0:
        qb = 1/kb * d**eb
    else:
        qb = -1/kb * (-d)**eb

    #scarico la falda
    g_f = g - qb

    #sistemo lo stato
    smax_f = ss - g_f

    et_f, rf_f, qb_f, s_f, smax_f, g_f = np.round(et1,1), np.round(rf,1), np.round(qb,1), np.round(s_f,1), np.round(smax_f,1), \
                                         np.round(g_f,1)
    return et_f, rf_f, qb_f, s_f, smax_f, g_f

def GW1(inf_in, etc, s_in, smin_in, smax_in, g_in, w0, kg,bg, bet, kb,eb, ss, iday, ncin, crsin, var,
       fn_raster, fn_zones):
    # df_Inf["mean"][iday], EC[iday,:,:], Si, MOORE_PAR["Smin_i"], Smaxi,
    # Gi, Wi, MOORE_PAR["Kg"], MOORE_PAR["Bg"], MOORE_PAR["bET"],
    # MOORE_PAR["Kb"],MOORE_PAR["eb"], SS
    s = float(s_in) + inf_in
    rf = np.round(1/kg*(s-smin_in)**bg,1)

    if rf> s - smin_in: rf = s-smin_in

    #scarico lo storage in falda
    s1 = s-rf

    ket  = 1 - (1 -s1/smax_in)**bet
    et = ket*etc
    et [et> s1 - smin_in] =  s1 - smin_in
    print(iday)
    df_et = daut.create_distric_analysis(iday, ncin, crsin, var, fn_raster, fn_zones)
    et1 = np.round(df_et["mean"][0],1)

    #et1 = np.mean(et[etc> -9999])
    #scarico l'evapotraspirazione in atmosfera
    s_f = s1-et1

    #ricarico la falda
    g = g_in + rf

    #calcolo il deflusso
    d = g -w0
    if d >= 0:
        qb = 1/kb * d**eb
    else:
        qb = -1/kb * (-d)**eb

    #scarico la falda
    g_f = g - qb

    #sistemo lo stato
    smax_f = ss - g_f

    et_f, rf_f, qb_f, s_f, smax_f, g_f = np.round(et1,1), np.round(rf,1), np.round(qb,1), np.round(s_f,1), np.round(smax_f,1), \
                                         np.round(g_f,1)
    return et_f, rf_f, qb_f, s_f, smax_f, g_f

def GW(inf_in, etc, s_in, smin_in, smax_in, g_in, w0, kg,bg, bet, kb,eb, ss):
    # df_Inf["mean"][iday], EC[iday,:,:], Si, MOORE_PAR["Smin_i"], Smaxi,
    # Gi, Wi, MOORE_PAR["Kg"], MOORE_PAR["Bg"], MOORE_PAR["bET"],
    # MOORE_PAR["Kb"],MOORE_PAR["eb"], SS
    s = float(s_in) + inf_in
    rf = np.round(1/kg*(s-smin_in)**bg,1)

    if rf> s - smin_in: rf = s-smin_in

    #scarico lo storage in falda
    s1 = s-rf

    ket  = 1 - (1 -s1/smax_in)**bet
    et = ket*etc
    if et> s1 - smin_in:
        et1 = s1 - smin_in
    else:
        et1=et

    #scarico l'evapotraspirazione in atmosfera
    s_f = s1-et1

    #ricarico la falda
    g = g_in + rf

    #calcolo il deflusso
    d = g -w0
    if d >= 0:
        qb = 1/kb * d**eb
    else:
        qb = -1/kb * (-d)**eb

    #scarico la falda
    g_f = g - qb

    #sistemo lo stato
    smax_f = ss - g_f

    et_f, rf_f, qb_f, s_f, smax_f, g_f = np.round(et1,1), np.round(rf,1), np.round(qb,1), np.round(s_f,1), np.round(smax_f,1), \
                                         np.round(g_f,1)
    return et_f, rf_f, qb_f, s_f, smax_f, g_f


