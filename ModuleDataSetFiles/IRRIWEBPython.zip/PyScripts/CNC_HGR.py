import numpy as np
import Utility.ioutil as iou
import definitions as de
import Utility.oper_interface as oi

MYPATH = iou.plane_xml_parser(de.mypath)


def RO_CNC_DAY(d_o_s, grid_tp, grid_antrf):
    par = iou.plane_xml_parser(MYPATH["par_CNC"])
    cn0 = iou.json_to_array(MYPATH["par_CN0"])
    am = float(par["BETA"])*np.sqrt(grid_antrf)
    St0 = (25400/cn0- 254)
    St = St0*St0/(St0+am)
    if d_o_s < 5:
        ia = float(par["LAMBDA"])*St
    else:
        ia = float(par["LAMBDA1"])*St*(grid_tp/(grid_tp + St))**float(par["ALPHA"])
    ia1 = np.where(ia<grid_tp, ia, grid_tp)
    rfet = grid_tp - ia1
    rfet1 = np.where(rfet>0,rfet,0)
    ro =np.round(rfet1**2/(rfet1+ St),1)
    ia1 = np.round(ia1,1)
    St = np.round(St,1)
    ro[grid_tp==-9999]= -9999
    ia1[grid_tp==-9999]= -9999
    St[grid_tp==-9999]= -9999

    return ro, ia1, St

def direct_runoff(k, tp,antrf):
    ro, ia, st = RO_CNC_DAY(k, tp, antrf)
    inf = np.round(tp  - ro - ia,1)
    inf[tp == -9999]=-9999
    return ro, ia, st, inf


def ET0_DAY_HRG(doy, grid_tm, grid_tM, Gsc,lat, conv):
    """
    Calcolo in griglia dell'evapotraspirazione potenziale col metodo Hargreaves 1985
    :param doy: giorno dell'anno
    :param grid_tm (array like): temperatura minima giornaliera in griglia [°C]
    :param grid_tM (array like): temperatura massima giornaliera in griglia [°C]
    :param grid_lat (array like): latitudine dei punti della griglia [deg] (EPGS: 4326 (WGS84))
    :param conversion: conversione unità (1 = [MJ m-2 day-1], default (0.408)=[mm day-1]
    :param gsc: costante solare di default 0.0820 [MJ m-2 min-1]
    :return:
    """
    #calcolo escursione termica e temperatura media
    grid_tc = (grid_tM + grid_tm)/2
    grid_tr = (grid_tM - grid_tm)
    #calcolo radiazione extraterrestre
    dr = 1 + 0.033*np.cos(2 * np.pi *doy/365)
    sd = 0.409 * np.sin(2 * np.pi * doy/365 - 1.39)
    tan_sd = np.tan(sd)
    sin_sd = np.sin(sd)
    cos_sd = np.cos(sd)
    ws = np.arccos(-tan_sd * np.tan(lat* np.pi/180))
    sin_ws = np.sin(ws)
    grid_ra =  24 * 60/np.pi * Gsc * dr *(ws * np.sin(lat* np.pi/180) * sin_sd +
                                          np.cos(lat* np.pi/180)*cos_sd * sin_ws)
    #calcolo Hargreaves 1985
    grid_et0 = np.round(conv* 0.0023 * grid_ra * (grid_tc + 17.8) *grid_tr**0.5,1)
    # set nan value
    grid_et0[np.where(grid_tc==-9999)]= -9999
    return grid_et0

def ETc_DAY_HGR(doy,month, tamin, tamax):
    lat = iou.json_to_array(MYPATH["par_ET_LAT"])
    kcdir = MYPATH["par_ET_KC"]
    par = iou.plane_xml_parser(MYPATH["par_ET"])
    ET0day = ET0_DAY_HRG(doy, tamin, tamax, float(par["Gsc"]),lat, float(par["conv"]))

    ET0day[tamin==-9999] = -9999

    return ET0day, np.round(ET0day,1)

def grid_CNC_HGR(sim, tp, tp_ts, tamin,tamax, list_antrf, ro_ts, ro, in_ts,inf,e0_ts,e0,ec_ts,ec):
    list_x=[]
    list_date=[]
    for iday in range(0, len(tp)):
        DOY, DATE_FMT, DATE_STR, YEAR_STR, MONTH_STR, DAY_STR = iou.nc_to_date(iday, tp_ts)
        list_x.append(DATE_FMT)
        list_date.append(DATE_STR)


        ###############################################################
        #get antecedent rainfall
        ###############################################################
        ANTRF = oi.get_ANTRF(iday, iday, tp, list_antrf)


        ###############################################################
        #chek if simulation is yhe first for cnc calulation and if
        # is necessary calculate grid evapo and runoff
        ###############################################################
        if sim["isFirst"]:
            d_o_s = iday
        else:
            d_o_s = 10

        if sim["isGridCalc"]:
            ###############################################################
            #direct runoff calculation
            ###############################################################
            ro_ts[iday] = iday
            in_ts[iday] = iday
            ro[iday,:,:], ia, st, inf[iday,:,:] = direct_runoff(d_o_s, tp[iday, :, :], ANTRF[:,:])
            ###############################################################
            #devapotraspiration calculation
            ###############################################################
            e0_ts[iday] = iday
            ec_ts[iday] = iday
            e0[iday,:,:], ec[iday,:,:] = ETc_DAY_HGR(DOY,MONTH_STR, tamin[iday, :, :], tamax[iday, :, :])
