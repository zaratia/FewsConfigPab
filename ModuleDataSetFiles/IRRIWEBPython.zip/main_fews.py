import numpy as np
import pandas as pd
import Utility.ioutil as iou
import Utility.oper_interface as oi
import PyScripts.CNC_HGR as fun_CNC_HGR
import PyScripts.MOORE as fun_MOORE
import matplotlib.pyplot as plt
import Utility.district_analysis_util as daut


###############################################################
#import simulation parameter and standard
###############################################################
fpath, fname = oi.read_path()
MYPATH = iou.plane_xml_parser(fpath)
MYNAME = iou.plane_xml_parser(fname)
SIM = iou.plane_xml_parser("simulation.xml")

###############################################################
#import variables and state variables and create result nc files
###############################################################

TAmax_ds, TAmin_ds, TP_ds, TAmax_ts, TAmin_ts, TP_ts, TAmax, TAmin, TP = oi.import_vars_CNC_HGR(MYPATH, MYNAME)
ANTRF1, ANTRF2, ANTRF3, ANTRF4, ANTRF5, SS, Gi, Smaxi, Si, Wi, VSTS_DATE = oi.get_vsts_CNC_HGR(MYPATH)
list_ANTRF = [ANTRF1, ANTRF2, ANTRF3, ANTRF4, ANTRF5]
RO_ds, RO_ts, RO_xs, RO_ys, RO, IN_ds, IN_ts, IN_xs, IN_ys, IN = oi.write_result_ro(MYPATH, SIM, MYNAME)
E0_ds, E0_ts, E0_xs, E0_ys, E0, EC_ds, EC_ts, EC_xs, EC_ys, EC = oi.write_result_et(MYPATH, SIM, MYNAME)


###############################################################
#perform grid calculation
###############################################################
fun_CNC_HGR.grid_CNC_HGR(SIM, TP, TP_ts, TAmin, TAmax, list_ANTRF,  RO_ts, RO, IN_ts,IN, E0_ts, E0, EC_ts,EC)


###############################################################
#prepare concentrate variables for district analysis
###############################################################
MOORE_PAR = iou.plane_xml_parser(MYPATH["par_MOORE"])
fn_zones = MYPATH["dir_SHP"] + MOORE_PAR["district"] + ".shp"
crsin = MOORE_PAR["crsin"]
temptiff ='temp.tiff'
fn_raster = temptiff
fout = MYPATH["out_INF"]
df_Inf = daut.create_distric_daily_analysis(fout, crsin, "INF", fn_raster, fn_zones)
fout = MYPATH["out_EC"]
df_Ec = daut.create_distric_daily_analysis(fout, crsin, "EC", fn_raster, fn_zones)

###############################################################
#district ground-water analysis
###############################################################
list_x=[]
list_gw=[]
list_qb=[]
list_s1=[]
list_rf=[]
list_rf1=[]
list_st=[]
list_sm=[]
list_et=[]


for iday in range(0, len(df_Inf)):
    DOY, DATE_FMT, DATE_STR, YEAR_STR, MONTH_STR, DAY_STR = iou.nc_to_date(iday, TP_ts)
    list_x.append(DATE_FMT)
    et_f, rf_f, qb_f, st_f, sm_f, gw_f = fun_MOORE.GW(df_Inf["mean"][iday], df_Ec["mean"][iday], Si, MOORE_PAR["Smin_i"], Smaxi,
                                                      Gi, Wi, MOORE_PAR["Kg"], MOORE_PAR["Bg"], MOORE_PAR["bET"],
                                                      MOORE_PAR["Kb"],MOORE_PAR["eb"], SS)

    #set state variables
    Smaxi = sm_f
    Si = st_f
    Gi = gw_f
    #write state variable
    oi.write_state(DATE_STR, SS, gw_f,st_f,Wi, MYPATH)

    list_gw.append(gw_f)
    list_rf.append(rf_f)
    list_qb.append(qb_f)
    list_st.append(st_f)
    list_sm.append(sm_f)
    list_et.append(et_f)


###############################################################
#write dataframe for calibration
###############################################################
fout = MYPATH["TP"]
df_TP = daut.create_distric_daily_analysis(fout, crsin, "TP", fn_raster, fn_zones)
fout = MYPATH["TAmax"]
df_TAmax = daut.create_distric_daily_analysis(fout, crsin, "TAmax", fn_raster, fn_zones)
fout = MYPATH["TAmin"]
df_TAmin = daut.create_distric_daily_analysis(fout, crsin, "TAmin", fn_raster, fn_zones)
fout = MYPATH["out_RO"]
df_RO = daut.create_distric_daily_analysis(fout, crsin, "RO", fn_raster, fn_zones)
fout = MYPATH["out_E0"]
df_ET0 = daut.create_distric_daily_analysis(fout, crsin, "E0", fn_raster, fn_zones)
fout = MYPATH["out_EC"]
df_ETC = daut.create_distric_daily_analysis(fout, crsin, "EC", fn_raster, fn_zones)

df_cal = pd.DataFrame()
df_cal["Day"] = list_x
df_cal["TP"] = np.round(df_TP["mean"],1)
df_cal["TAmax"] = np.round(df_TAmax["mean"],1)
df_cal["TAmin"] = np.round(df_TAmin["mean"],1)
df_cal["RO"] = np.round(df_RO["mean"],1)
df_cal["Inf"] = np.round(df_Inf["mean"],1)
df_cal["ET0"] = np.round(df_ET0["mean"],1)
df_cal["ET"] = np.round(list_et,1)
df_cal["Smax"] = np.round(list_sm,1)
df_cal["St"] = np.round(list_st,1)
df_cal["Rf"] = np.round(list_rf,1)
df_cal["GW"] = np.round(list_gw,1)
df_cal["Qb"] = np.round(list_qb,1)

df_cal.to_csv(MYPATH["out_CALIB"])


df_res_ro = pd.DataFrame()
df_res_ro["Day"] = list_x
df_res_ro["District"] = MOORE_PAR["district"]
df_res_ro["RO"] = np.round(df_RO["mean"],1)

df_res_qb = pd.DataFrame()
df_res_qb["Day"] = list_x
df_res_qb["District"] = MOORE_PAR["district"]
df_res_qb["Qb"] = np.round(list_qb,1)

df_res_et = pd.DataFrame()
df_res_et["Day"] = list_x
df_res_et["District"] = MOORE_PAR["district"]
df_res_et["ET"] = np.round(list_et,1)

df_res_ro.to_csv(MYPATH["out_RO"])
df_res_qb.to_csv(MYPATH["out_Qb"])
df_res_et.to_csv(MYPATH["out_ET"])

#plt.plot(df_cal["ET0"])
#plt.show()

print("Precipitation: ",np.sum(df_cal["TP"]))
print("Direct runoff: ",np.sum(df_cal["RO"]))
print("Infiltration: ",np.sum(df_cal["Inf"]))
print("Ground infiltration Gf: ",np.sum(df_cal["Rf"]))
print("Gound runoff Qb: ",np.sum(df_cal["Qb"]))
print("Evapotraspiration ET: ",np.sum(df_cal["ET"]))
print("dG: ",np.sum(df_cal["GW"][0]-df_cal["GW"][len(df_cal)-1]))
print("dS: ",np.sum(df_cal["St"][0]-df_cal["St"][len(df_cal)-1]))


