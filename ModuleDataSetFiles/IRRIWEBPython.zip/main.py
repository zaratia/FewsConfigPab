import Utility.ioutil as iou
import definitions as de

print(de.prjroot)

iou.dict_to_json({"a":1}, "prova.json")