C:\Users\Mattia\.conda\envs\LEB2\python.exe main_fews.py
pause