import src.utility.ioutil as iou
from osgeo import gdal

tif_name = "CN_2.tif"
ds = gdal.Open(tif_name, gdal.GA_ReadOnly)

# Get the first raster band
band = ds.GetRasterBand(1)
data = band.ReadAsArray()
print(data.shape)

iou.array_to_json(data,"grid_cn.json")