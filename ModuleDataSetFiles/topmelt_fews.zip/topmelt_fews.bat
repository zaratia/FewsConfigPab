@echo on
call "C:\Users\matti\miniforge3\Scripts\activate.bat"
call conda activate pyictop
set PYTHONPATH=%PYTHONPATH%;C:\Users\matti\Progetti\02_FEWS-BZ\00_FEWS\Modules\spyic-top
cd "C:\Users\matti\Progetti\02_FEWS-BZ\00_FEWS\Modules\spyic-top\scripts"
python "main_snow_fews.py"
echo Exit code: %errorlevel%
pause